#include "Game.h"

 // Name: Game() Default Constructor
  // Desc - Empty default constructor
  // Preconditions - None
  // Postconditions - None
Game::Game(){} //Default Constructor
  // Name: LoadRecipes
  // Desc - A recipe is what elements are required to merge in order to create a new element
  //        For example, if you merge Fire and Earth, you get Lava.
  //        Loads each recipe from provided file (Must use getline)
  // Preconditions - Requires file with valid element/recipe data
  // Postconditions - m_elements is populated with valid recipe data
void Game::LoadRecipes() {
  ifstream myFile(PROJ2_RECIPES);

  if(myFile.is_open()) {
    string name, element1, element2;
    int index = 0; // using the index to track where we are in m_elements

    while (getline(myFile, name, ',') && getline(myFile, element1, ',') && getline(myFile, element2) && index < PROJ2_SIZE) {
      m_elements[index] = Element(name, element1, element2); //store the elements in array as an Element object
      index++;
    }

    myFile.close();
  } else {
    cout << PROJ2_RECIPES << " did not open. " << endl;
  }
}



  // Name: StartGame()
  // Desc: 1. Loads all recipes into m_elements (by making elements)
  //       2. Asks user for their DoodleGod's name
  //          (store in m_myDoodleGod as m_myName)
  //       3. Adds Fire, Water, Air, and Earth to Doodle God's known element list
  //          (in m_myDoodleGod)
  //       4. Manages the game itself including win conditions continually
  //         calling the main menu
  // Preconditions - None
  // Postconditions - Continually checks to see if player has quit
void Game::StartGame() {
  GameTitle();
  LoadRecipes();
  string name;
  cout << "Enter your DoodleGod's name: ";
  getline(cin, name);
  m_myDoodleGod.SetName(name);

  //add starting elements
  m_myDoodleGod.AddElement(Element("Air", "", ""));
  m_myDoodleGod.AddElement(Element("Earth", "", ""));
  m_myDoodleGod.AddElement(Element("Fire", "", ""));
  m_myDoodleGod.AddElement(Element("Water", "", ""));

  int choice;

  do {
    choice = MainMenu();
    switch (choice) {
    case 1:
      DisplayElements();
      break;
    case 2:
      CombineElements();
      break;
    case 3:
      CalcScore();
      break;
    case 4:
      cout << "Thanks for playing the Doodle God!" << endl;
      break;
    }
  } while (choice != 4);
}





  // Name: DisplayMyElements()
  // Desc - Displays the current elements
  // Preconditions - Player has elements
  // Postconditions - Displays a numbered list of elements
void Game::DisplayElements(){
  m_myDoodleGod.DisplayElements();
}
  // Name: MainMenu()
  // Desc - Displays and manages menu
  // Preconditions - Player has an DoodleGod
  // Postconditions - Returns number including exit
int Game::MainMenu(){
  int choice = 0;
  while (choice < 1 || choice > 4) {
    cout << "What would you like to do?" << endl;
    cout << "1. Display the Doodle God's Elements" << endl;
    cout << "2. Attempt to Combine Elements" << endl;
    cout << "3. See Score" << endl;
    cout << "4. Quit" << endl;
    cout << "Choose an option: ";
    cin >> choice;
  }
  return choice;
}

  
  // Name: CombineElements()
  // Desc - Attempts to combine known elements
  // Preconditions - DoodleGod is populated with elements
  // Postconditions - May add element to DoodleGod's list of elements
void Game::CombineElements(){
  int choice1, choice2;
  RequestElement(choice1);
  RequestElement(choice2);

  string element1 = m_myDoodleGod.GetElement(choice1 - 1).m_name;
  string element2 = m_myDoodleGod.GetElement(choice2 - 1).m_name;

  int resultIndex = SearchRecipes(element1, element2);

  m_myDoodleGod.AddAttempt();

  if (resultIndex != -1) {
    Element newElement = m_elements[resultIndex];
    if (m_myDoodleGod.CheckElement(newElement)) {
      cout << "Already discovered " << newElement.m_name << "!" << endl;
      m_myDoodleGod.AddRepeat();
    } else {
      m_myDoodleGod.AddElement(newElement);
      cout << element1 << " combined with " << element2 << " to make " << newElement.m_name << "!" << endl;
      cout << "The Doodle God now knows " << newElement.m_name << "." << endl;
    }
  } else {
    cout << "Nothing happened when you tried to combine " << element1 << " and " << element2 << "" << endl;
  }
}




  // Name: RequestElement()
  // Desc - Asks user to chose an element to try and merge.
  //        Checks to make sure value in range
  // Preconditions - DoodleGod has elements to try and merge
  // Postconditions - Updates choice (pass by reference)
void Game::RequestElement(int &choice){
  do {
    cout << "Choose an element (-1 to display all elements): ";
    cin >> choice;
    if (choice == -1) {
      DisplayElements();
    }
  } while (choice < 1 || choice > m_myDoodleGod.GetNumElements());
}
  
 
    
  // Name: SearchRecipes()
  // Desc - Searches recipes for two strings passed
  // Preconditions - m_elements is populated
  // Postconditions - Returns int index of matching recipe
int Game::SearchRecipes(string element1, string element2){
  for (int i = 0; i < PROJ2_SIZE; i++) {
    if ((m_elements[i].m_element1 == element1 && m_elements[i].m_element2 == element2) ||
	(m_elements[i].m_element1 == element2 && m_elements[i].m_element2 == element1)) {
      return i;
    }
  }
  return -1;
}
  // Name: CalcScore()
  // Desc - Displays current score for Doodle God
  // Preconditions - Doodle God is populated with elements
  // Postconditions - None
void Game::CalcScore(){
  int totalElements = m_myDoodleGod.GetNumElements();
  int attempts = m_myDoodleGod.GetAttempts();
  int repeats = m_myDoodleGod.GetRepeats();
  double percentage = ((double)totalElements / PROJ2_SIZE) * 100.0;

  cout << "***The Doodle God***" << endl;
  cout << "The Great Doodle God " << m_myDoodleGod.GetName() << endl;
  cout << "The Doodle God has tried to combine " << attempts << " elements" << endl;
  cout << "The Doodle God has repeated attempts " << repeats << " times" << endl;
  cout << "The Doodle God found " << totalElements << " out of " << PROJ2_SIZE << " elements." << endl;
  cout << fixed << setprecision(2) << "You have completed " << percentage << "% of the elements." << endl;
}
 


