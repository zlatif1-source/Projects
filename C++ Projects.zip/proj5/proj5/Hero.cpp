#include "Hero.h"
#include <cstdlib>
#include <iostream>
using namespace std;

Hero::Hero(const string& name) : m_name(name), m_inventory() { }

Hero::~Hero() { }

string Hero::GetName() const {
    return m_name;
}

void Hero::SetName(const string& name) {
    m_name = name;
}

void Hero::DisplayInventory() const {
    cout << "Inventory for " << m_name << ":\n";
    cout << m_inventory;
}

void Hero::CollectItem(const string& item) {
    try {
        int count = m_inventory.ValueAt(item);
        m_inventory.Update(item, count + 1);
    }
    catch (const out_of_range&) {
        m_inventory.Insert(item, 1);
    }
}

bool Hero::CanCraft(const vector<string>& requirements) const {
  for (const auto &req : requirements) {
    if (req != "None") {
      try {
	int count = m_inventory.ValueAt(req);
	if (count < 1) {
	  return false;
	}
      } catch (const out_of_range&) {
	return false;
      }
    }
    
  }
  return true;
}

void Hero::Craft(const string& result, const vector<string>& requirements) {
  if (!CanCraft(requirements)) {
    cout << "Cannot craft " << result << ". Missing requirements." << endl;
    return;
  }
    
  for (const auto &req : requirements) {
    if (req != "None") {
      try {
	int count = m_inventory.ValueAt(req);
	m_inventory.Update(req, count - 1);
      } catch (const out_of_range&) {
               
      }
    }
  }
    
  CollectItem(result);
  cout << "Crafted: " << result << "!" << endl;
}

void Hero::Gather(const vector<string>& products, const string& noItemMsg,
                  const string& foundMsg) {
    if (products.empty())
        return;
    int size = products.size();
    int index = rand() % (size + 1);
    if (index == size) {
        cout << noItemMsg << "\n";
    }
    else {
        string item = products[index];
        cout << foundMsg << item << "\n";
        CollectItem(item);
    }
}

void Hero::Raw() {
    Gather(RawProducts, "You found no raw materials.", "You mined: ");
}

void Hero::Natural() {
    Gather(NaturalProducts, "You found no natural resources.", "You foraged and found: ");
}

void Hero::Food() {
    Gather(FoodProducts, "You found no food items.", "You gathered food: ");
}

void Hero::Hunt() {
    Gather(HuntProducts, "You found no creature drops.", "You hunted and obtained: ");
}


