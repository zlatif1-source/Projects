#include "Item.h"

Item::Item(const string& name, const vector<string>& requirements)
    : m_name(name), m_req(requirements) { }

string Item::GetName() const {
    return m_name;
}

const vector<string>& Item::GetReq() const {
    return m_req;
}

