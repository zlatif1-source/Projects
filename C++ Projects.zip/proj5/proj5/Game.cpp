#include "Game.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <ctime>
#include <cctype>
using namespace std;

Game::Game(string areaFile, string craftFile)
  : m_myHero(nullptr), m_curArea(START_AREA), m_craftFile(craftFile), m_areaFile(areaFile) { }

Game::~Game() {
  for (size_t i = 0; i < m_areas.size(); i++) {
    delete m_areas[i];
  }
  for (size_t i = 0; i < m_items.size(); i++) {
    delete m_items[i];
  }
  delete m_myHero;
}

void Game::LoadMap() {
  ifstream inFile(m_areaFile);
  if (!inFile) {
    cout << "Error opening area file: " << m_areaFile << endl;
    return;
  }
  string line;
  while (getline(inFile, line)) {
    if (line != "") {
      stringstream ss(line);
      string token;
      int id, north, east, south, west;
      string name, desc;
      getline(ss, token, DELIMITER);
      id = stoi(token);
      getline(ss, name, DELIMITER);
      getline(ss, desc, DELIMITER);
      getline(ss, token, DELIMITER);
      north = stoi(token);
      getline(ss, token, DELIMITER);
      east = stoi(token);
      getline(ss, token, DELIMITER);
      south = stoi(token);
      getline(ss, token, DELIMITER);
      west = stoi(token);
      Area* area = new Area(id, name, desc, north, east, south, west);
      m_areas.push_back(area);
    }
  }
  inFile.close();
}

void Game::LoadCraft() {
  ifstream inFile(m_craftFile);
  if (!inFile) {
    cout << "Error opening craft file: " << m_craftFile << endl;
    return;
  }
  string line;
  while (getline(inFile, line)) {
    if (line != "") {
      stringstream ss(line);
      string token;
      vector<string> tokens;
      while (getline(ss, token, DELIMITER)) {
	tokens.push_back(token);
      }
      if (tokens.size() >= 1) {
	string itemName = tokens[0];
	vector<string> req;
	for (size_t i = 1; i < tokens.size(); i++) {
	  req.push_back(tokens[i]);
	}
	Item* item = new Item(itemName, req);
	m_items.push_back(item);
      }
    }
  }
  inFile.close();
}

void Game::HeroCreation() {
  cout << "Hero Name: ";
  string name;
  getline(cin, name);
  while (name == "") {
    cout << "Hero Name: ";
    getline(cin, name);
  }
  m_myHero = new Hero(name);
}

void Game::Look() {
  if (m_curArea < 0 || m_curArea >= (int)m_areas.size()) {
    cout << "Current area is invalid." << endl;
    return;
  }
  m_areas[m_curArea]->PrintArea();
}

void Game::StartGame() {
  cout << "Welcome to UMBC Runescape!" << endl;
  srand(time(0));
  LoadMap();
  LoadCraft();
  HeroCreation();
  m_curArea = START_AREA;
  Look();
  Action();
}

void Game::Action() {
  int choice = 0;
  while (true) {
    cout << "\nWhat would you like to do?" << endl;
    cout << "1. Look" << endl;
    cout << "2. Move" << endl;
    cout << "3. Use Area" << endl;
    cout << "4. Craft Item" << endl;
    cout << "5. Display Inventory" << endl;
    cout << "6. Quit" << endl;
    cin >> choice;
    cin.ignore();
    switch (choice) {
    case 1:
      Look();
      break;
    case 2:
      Move();
      break;
    case 3:
      UseArea();
      break;
    case 4:
      CraftItem();
      break;
    case 5:
      cout << "******* INVENTORY *******" << endl;
      m_myHero->DisplayInventory();
      break;
    case 6:
      cout << "Good bye!" << endl;
      return;
    default:
      cout << "Invalid selection. Try again." << endl;
    }
  }
}

void Game::Move() {
  bool validMove = false;
  while (!validMove) {
    cout << "Which direction? (N E S W)" << endl;
    char dir;
    cin >> dir;
    cin.ignore();
    int nextID = m_areas[m_curArea]->CheckDirection(dir);
    if (nextID == -1) {
      cout << "No exit in that direction." << endl;
    } else {
      bool found = false;
      size_t i = 0;
      while (i < m_areas.size() && (!found)) {
	if (m_areas[i]->GetID() == nextID) {
	  m_curArea = i;
	  found = true;
	}
	i++;
      }
      if (!found) {
	cout << "Area with ID " << nextID << " not found." << endl;
      } else {
	validMove = true;
	Look();
      }
    }
  }
}

void Game::CraftItem() {
  if (m_items.empty()) {
    cout << "No craftable items available." << endl;
    return;
  }
  cout << "Which item would you like to craft?" << endl;
  for (size_t i = 0; i < m_items.size(); i++) {
    cout << i + 1 << ". " << m_items[i]->GetName() << endl;
  }
  int selection = 0;
  cin >> selection;
  cin.ignore();
  if (selection < 1 || selection > (int)m_items.size()) {
    cout << "Invalid selection." << endl;
    return;
  }
  Item* selectedItem = m_items[selection - 1];
  if (m_myHero->CanCraft(selectedItem->GetReq())) {
    m_myHero->Craft(selectedItem->GetName(), selectedItem->GetReq());
  } else {
    cout << "Cannot craft " << selectedItem->GetName() << ". Missing requirements." << endl;
  }
}

void Game::UseArea() {
  cout << "What would you like to look for?" << endl;
  cout << "1. Raw Materials (Mining)" << endl;
  cout << "2. Natural Resources (Woodcutting/Foraging)" << endl;
  cout << "3. Food (Fishing/Farming)" << endl;
  cout << "4. Hunt" << endl;
  int action = 0;
  cin >> action;
  cin.ignore();
  switch (action) {
  case 1:
    m_myHero->Raw();
    break;
  case 2:
    m_myHero->Natural();
    break;
  case 3:
    m_myHero->Food();
    break;
  case 4:
    m_myHero->Hunt();
    break;
  default:
    cout << "Invalid action." << endl;
  }
}


