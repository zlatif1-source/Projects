#include "Area.h"
#include <iostream>
#include <cctype>
using namespace std;

Area::Area(int id, string name, string desc, int north, int east, int south, int west) {
    m_ID = id;
    m_name = name;
    m_desc = desc;
    m_direction[0] = north;
    m_direction[1] = east;
    m_direction[2] = south;
    m_direction[3] = west;
}

string Area::GetName() {
    return m_name;
}

int Area::GetID() {
    return m_ID;
}

string Area::GetDesc() {
    return m_desc;
}

int Area::CheckDirection(char myDirection) {
    char dir = tolower(myDirection);
    int index;
    switch (dir) {
        case 'n':
            index = 0;
            break;
        case 'e':
            index = 1;
            break;
        case 's':
            index = 2;
            break;
        case 'w':
            index = 3;
            break;
        default:
            return -1;
    }
    return m_direction[index];
}

void Area::PrintArea() {
  cout << endl;
  cout << m_name << endl;
  cout << endl;
  cout << m_desc << endl;
  cout << endl;
  cout << "Possible Exits: ";
  bool hasExit = false;
  if (m_direction[0] != -1) {
    cout << "North ";
    hasExit = true;
  }
  if (m_direction[1] != -1) {
    cout << "East ";
    hasExit = true;
  }
  if (m_direction[2] != -1) {
    cout << "South ";
    hasExit = true;
  }
  if (m_direction[3] != -1) {
    cout << "West ";
    hasExit = true;
    }
  if (!hasExit)
    cout << "None";
  cout << "\n";
}

