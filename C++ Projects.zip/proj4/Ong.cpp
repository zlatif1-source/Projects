#include "Ong.h"
using namespace std;

// Default constructor
Ong::Ong() : Cipher() {}

// Overloaded constructor
Ong::Ong(string message, bool isEncrypted) : Cipher(message, isEncrypted) {}

// Destructor
Ong::~Ong() {}


bool Ong::IsVowel(char c) {
  c = (c >= 'A' && c <= 'Z') ? c + 32 : c; 
  return (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' || c == ' ');
}


bool Ong::IsPunct(char c) {
  return !((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || c == ' ');
}

// Encrypt function
void Ong::Encrypt() {
  if (GetIsEncrypted()) return; 

  stringstream ss;
  string msg = GetMessage();

  for (unsigned int i = 0; i < msg.size(); i++) {
    char c = msg[i];
    ss << c;

    if (IsPunct(c)) {
    } else if (IsVowel(c)) {
      ss << "-";
    } else {
      ss << ong << "-";
    }
  }

  SetMessage(ss.str());
  ToggleEncrypted();
}

// Decrypt function
void Ong::Decrypt() {
  if (!GetIsEncrypted()) return; 

  stringstream ss;
  string msg = GetMessage();
  unsigned int i = 0;

  while (i < msg.size()) {
    char c = msg[i];
    ss << c;
    i++;

    if (IsPunct(c)) {
    } else if (IsVowel(c)) {
      if (i < msg.size() && msg[i] == '-') {
        i++;
      }
    } else {
      if (msg.substr(i, 3) == ong) {
        i += 3;
        if (i < msg.size() && msg[i] == '-') {
          i++; 
        }
      }
    }
  }

  SetMessage(ss.str());
  ToggleEncrypted();
}


string Ong::ToString() {
  return "Ong";
}

string Ong::FormatOutput() {
  stringstream ss;
  ss << "o" << DELIMITER
     << GetIsEncrypted() << DELIMITER
     << GetMessage() << DELIMITER << endl;
  return ss.str();
}
