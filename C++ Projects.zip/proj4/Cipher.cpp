#include "Cipher.h"


Cipher::Cipher() {
  m_message = "";
  m_isEncrypted = false;
}


Cipher::Cipher(string message, bool isEncrypted) {
  m_message = message;
  m_isEncrypted = isEncrypted;
}


Cipher::~Cipher() {
  //since no dynamic allocation
}

string Cipher::GetMessage() {
  return m_message;
}


bool Cipher::GetIsEncrypted() {
  return m_isEncrypted;
}


void Cipher::SetMessage(string message) {
  m_message = message;
}


void Cipher::ToggleEncrypted() {
  m_isEncrypted = !m_isEncrypted;
}


ostream &operator<<(ostream &output, Cipher &C) {
  output << C.GetMessage();
  return output;
}
