#include "Scytale.h"
#include <sstream> // for stringstream
using namespace std;


Scytale::Scytale() : Cipher(), m_key(0) {}


Scytale::Scytale(string message, bool isEncrypted, int key)
    : Cipher(message, isEncrypted), m_key(key) {}

// Destructor
Scytale::~Scytale() {}


void Scytale::Encrypt() {
    string message = GetMessage();
    int length = message.length();

    
    int numRows = (length + m_key - 1) / m_key;

    
    string encrypted = "";

    
    for (int col = 0; col < m_key; col++) {
        for (int row = 0; row < numRows; row++) {
            int index = row * m_key + col;
            if (index < length) {
                encrypted += message[index];
            }
        }
    }

    
    SetMessage(encrypted);
    ToggleEncrypted();
}


void Scytale::Decrypt() {
    string message = GetMessage();
    int length = message.length();

    
    int numRows = (length + m_key - 1) / m_key;

    
    string decrypted = message;
    int index = 0;

    
    for (int col = 0; col < m_key; col++) {
        for (int row = 0; row < numRows; row++) {
            int pos = row * m_key + col;
            if (pos < length) {
                decrypted[pos] = message[index];
                index++;
            }
        }
    }

    
    SetMessage(decrypted);
    ToggleEncrypted();
}


string Scytale::ToString() {
    return "Scytale";
}


string Scytale::FormatOutput() {
    stringstream ss;
    ss << ToString() << DELIMITER
       << GetIsEncrypted() << DELIMITER
       << GetMessage() << DELIMITER
       << m_key << DELIMITER;
    return ss.str();
}
