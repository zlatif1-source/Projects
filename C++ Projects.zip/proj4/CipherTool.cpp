#include "CipherTool.h"
#include <fstream>
#include <iostream>
#include <sstream>
using namespace std;


CipherTool::CipherTool(string filename) {
  m_filename = filename;
}


CipherTool::~CipherTool() {
  for (unsigned int i = 0; i < m_ciphers.size(); i++) {
    delete m_ciphers[i];
  }
  m_ciphers.clear();
}


void CipherTool::LoadFile() {
  ifstream inputFile(m_filename);
  if (!inputFile) {
    cout << "Unable to open file: " << m_filename << endl;
    return;
  }

  string type, isEncryptedStr, message, keyStr;
  while (getline(inputFile, type, '|')) {
    getline(inputFile, isEncryptedStr, '|');
    getline(inputFile, message, '|');
    getline(inputFile, keyStr); 

    bool isEncrypted = StringToBoolean(isEncryptedStr);

    if (type == "a") {
      Cipher* atbash = new Atbash(message, isEncrypted);
      m_ciphers.push_back(atbash);
    }
    else if (type == "s") {
      int key = stoi(keyStr);
      Cipher* scytale = new Scytale(message, isEncrypted, key);
      m_ciphers.push_back(scytale);
    }
    else if (type == "o") {
      Cipher* ong = new Ong(message, isEncrypted);
      m_ciphers.push_back(ong);
    }
  }
  inputFile.close();
}


bool CipherTool::StringToBoolean(string input) {
  return (input != "0");
}


void CipherTool::DisplayCiphers() {
  for (unsigned int i = 0; i < m_ciphers.size(); i++) {
    cout << (i + 1) << ". " << m_ciphers[i]->ToString()
         << " (" << (m_ciphers[i]->GetIsEncrypted() ? "Encrypted" : "Decrypted")
         << "): " << m_ciphers[i]->GetMessage() << endl;
  }
}


void CipherTool::EncryptDecrypt(bool doEncrypt) {
  for (unsigned int i = 0; i < m_ciphers.size(); i++) {
    if (doEncrypt) {
      if (!m_ciphers[i]->GetIsEncrypted()) {
        m_ciphers[i]->Encrypt();
      }
    } else {
      if (m_ciphers[i]->GetIsEncrypted()) {
        m_ciphers[i]->Decrypt();
      }
    }
  }
}


void CipherTool::Export() {
  string outputFile;
  cout << "What would you like to call your output file? " << endl;
  cin >> outputFile;
  
  ofstream outFile(outputFile);
  if (!outFile) {
    cout << "Unable to open export file." << endl;
    return;
  }

  for (unsigned int i = 0; i < m_ciphers.size(); i++) {
    outFile << m_ciphers[i]->FormatOutput();
  }
  outFile.close();
  cout << "Ciphers exported to " << outputFile << endl;
}


int CipherTool::Menu() {
  int choice;
  cout << "\nWhat would you like to do?\n";
  cout << "1. Display Ciphers" << endl;
  cout << "2. Encrypt Ciphers" << endl;
  cout << "3. Decrypt Ciphers" << endl;
  cout << "4. Export Ciphers" << endl;
  cout << "5. Quit" << endl;
  cout << "Enter your choice: ";
  cin >> choice;
  return choice;
}

void CipherTool::Start() {
  LoadFile();
  int choice = 0;

  do {
    choice = Menu();
    if (choice == 1) {
      DisplayCiphers();
    } else if (choice == 2) {
      EncryptDecrypt(true);
      cout << "Ciphers encrypted." << endl;
    } else if (choice == 3) {
      EncryptDecrypt(false);
      cout << "Ciphers decrypted." << endl;
    } else if (choice == 4) {
      Export();
    } else if (choice == 5) {
      cout << "Thanks for using UMBC encryption!" << endl;
    } else {
      cout << "Invalid choice. Try again." << endl;
    }
  } while (choice != 5);
}
