#include "Atbash.h"


Atbash::Atbash() : Cipher() {
  
}


Atbash::Atbash(string message, bool isEncrypted) : Cipher(message, isEncrypted) {
  
}

// Destructor
Atbash::~Atbash() {
  
}


void Atbash::Encrypt() {
  if (!GetIsEncrypted()) {
    string message = GetMessage();
    string result = "";

    for (unsigned i = 0; i < message.length(); i++) {
      char c = message[i];
      if (c >= 'A' && c <= 'Z') {
        result += 'Z' - (c - 'A');
      } else if (c >= 'a' && c <= 'z') {
        result += 'z' - (c - 'a');
      } else {
        result += c;
      }
    }
    SetMessage(result);
    ToggleEncrypted();
  }
}


void Atbash::Decrypt() {
  if (GetIsEncrypted()) {
    string message = GetMessage();
    string result = "";

    for (unsigned i = 0; i < message.length(); i++) {
      char c = message[i];
      if (c >= 'A' && c <= 'Z') {
        result += 'Z' - (c - 'A');
      } else if (c >= 'a' && c <= 'z') {
        result += 'z' - (c - 'a');
      } else {
        result += c;
      }
    }
    SetMessage(result);
    ToggleEncrypted();
  }
}


string Atbash::ToString() {
  return "Atbash";
}


string Atbash::FormatOutput() {
  stringstream ss;
  ss << ToString() << DELIMITER
     << GetIsEncrypted() << DELIMITER
     << GetMessage() << DELIMITER;
  return ss.str();
}
