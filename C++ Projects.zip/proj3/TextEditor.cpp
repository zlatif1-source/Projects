#include "TextEditor.h"


 // Name - TextEditor - default constructor
  // Desc - Set m_fileName to empty
  // Preconditions - None
  // Postconditions - Set m_fileName to empty. Creates document (m_editor)
TextEditor::TextEditor(){
  m_fileName = "";
  m_editor = Document();
  


}
  // Name - MainMenu
  // Desc - Displays options:
  //        1. Insert Line, 2. Delete Line, 3. Edit Line, 4. Display Document
  //        5. Search Word, 6. Save to File, 7. Load from File, 8. Exit
  // Preconditions - None
  // Postconditions - Returns valid choice (1-8)
int TextEditor::MainMenu(){
  int choice;
  cout << "--- Simple Text Editor ---" << endl;
  cout << "1. Insert Line" << endl;
  cout << "2. Delete Line" << endl;
  cout << "3. Edit Line" << endl;
  cout << "4. Display Document" << endl;
  cout << "5. Search Word" << endl;
  cout << "6. Save to File" << endl;
  cout << "7. Load from File" << endl;
  cout << "8. Exit" << endl;
  cout << "Enter your choice: ";
  cin >> choice;
  return choice;
}

  // Name - GetLineNumber
  // Desc - Allows user to choose a specific line number from document.
  //        For functions such as DeleteLine and EditLine, the line number must be exact
  //            (between 1 and the number of lines in the document)
  //        For InsertLine, the line must be between 1 and the number of lines + 1
  // Preconditions - Document (m_editor) exists
  // Postconditions - Returns line chosen
int TextEditor::GetLineNumber(bool isExact){
  int lineNumber;
  int lineCount = m_editor.GetLineCount();

  if (lineCount == 0) {
    if (!isExact) {
      cout << "The document is empty. Inserting at line 1.\n";
      return 1;
    } else {
      cout << "The document is empty. There are no lines to delete or edit.\n";
      return -1;  
    }
  }
  

  cout << "Enter line number (1 to " << (isExact ? lineCount : lineCount + 1) << "): ";
  cin >> lineNumber;
  
  while (cin.fail() || lineNumber < 1 || lineNumber > (isExact ? lineCount : lineCount + 1)) {
    cin.clear();
    cin.ignore(1000, '\n');
    cout << "Must be between 1 and " << (isExact ? lineCount : lineCount + 1) << endl;
    cout << "Enter line number: ";
    cin >> lineNumber;
  }
  
  
  return lineNumber;
}





  // Name - GetFileName
  // Desc - Prompts user for file name. Stores in m_fileName
  // Preconditions - None
  // Postconditions - Returns file name entered
string TextEditor::GetFileName(){
  cout << "Enter the file name: ";
        string fileName;
        cin >> fileName;
        return fileName;
    }





  // Name - Start
  // Desc - Calls MainMenu. Takes menu response and uses switch statement to
  //        call corresponding function (display just calls DisplayDocument)
  //        Keeps calling until user enters 8 (quit).
  // Preconditions - None
  // Postconditions - Keeps asking user what to do until they enter 8 (quit).

void TextEditor::Start(){
  int choice;
  do {
    choice = MainMenu(); 
    switch (choice) {
    case 1: {
      InsertLine();
      break;
    }
    case 2: {
      DeleteLine();
      break;
    }
    case 3: {
      EditLine();
      break;
    }
    case 4: {
      m_editor.DisplayDocument();
      break;
    }
    case 5: {
      SearchDocument();
      break;
    }
    case 6: {
      SaveFile();
      break;
    }
    case 7: {
      LoadFile();
      break;
    }
    case 8: {
      cout << "Exiting...\n";
      break;
    }
    default: {
      cout << "Invalid choice! Try again.\n";
      break;
            }
    }
  } while (choice != 8);  
}



  // Name - InsertLine
  // Desc - Inserts a new line into the document(m_editor). Asks user where to
  //        insert the new line by calling GetLineNumber. Inserts the new line before
  //        the line chosen.
  // Preconditions - None
  // Postconditions - Inserts line into document (m_editor).
void TextEditor::InsertLine(){
  cout << "**Insert Line**" << endl;

  cout << "Enter text: ";
  string newText;
  cin.ignore();
  getline(cin, newText);

  int lineNumber = GetLineNumber(false);
  
  if (lineNumber != -1) {
    m_editor.InsertLine(newText, lineNumber);
  }
  
}

  // Name - DeleteLine
  // Desc - Checks to make sure the document(m_editor) has lines. If it does,
  //        calls GetLineNumber. Then deletes line from document.
  // Preconditions - Document has at least one line.
  // Postconditions - Removes line from document (m_editor).
void TextEditor::DeleteLine(){
  int lineNumber = GetLineNumber(true);
  m_editor.DisplayDocument();
  if (lineNumber != -1) {
    m_editor.DeleteLine(lineNumber);
    m_editor.DisplayDocument();
  }
}

  // Name - EditLine
  // Desc - Checks to make sure the document(m_editor) has lines. If it does,
  //        calls GetLineNumber. Updates the text in the chosen line.
  // Preconditions - Document has at least one line.
  // Postconditions - Updates line from document (m_editor).
void TextEditor::EditLine(){
  int lineNumber = GetLineNumber(true);
  
  
  if (lineNumber == -1) return;
  
  cout << "Enter new text: ";
  cin.ignore();
  string newText;
  getline(cin, newText);
  m_editor.EditLine(lineNumber, newText);
}


//  // Name - SearchDocument
//   // Desc - Checks to make sure the document(m_editor) has lines. If it does,
//   //        asks user which text to search for. Displays all lines that have
//   //        the matching text.
//   // Preconditions - Document has at least one line.
//   // Postconditions - Displays line from document (m_editor).
//
void TextEditor::SearchDocument(){
     if (m_editor.GetLineCount() > 0) {
        string searchText;
        cout << "Enter text to search for: ";
        cin.ignore();
	getline(cin, searchText);
	m_editor.SearchWord(searchText);
    } else {
        cout << "The document is empty. No lines to search." << endl;
    }
}
  
  // Name - LoadFile
  // Desc - Asks user for the file name. Opens file. Inserts lines from file
  //        into existing document (m_editor). Appends document (m_editor).
  // Preconditions - None
  // Postconditions - Inserts text from file into document (m_editor).
void TextEditor::LoadFile(){

  string filename = GetFileName();
  m_editor.LoadFromFile(filename);
}

  // Name - SaveFile
  // Desc - Asks user for the file name. Opens file. Writes out all lines from
  //        document (m_editor) to the file.
  // Preconditions - None
  // Postconditions - Inserts text from document (m_editor) into file.
void TextEditor::SaveFile(){
  string filename = GetFileName();
  m_editor.SaveToFile(filename);
}
