
#include "Document.h"

  // Name - Document() - Default constructor
  // Desc - Creates an empty Document (linked list)
  // Preconditions - None
  // Postconditions - Sets m_head to nullptr and m_lineCount = 0
Document::Document(){
  m_head = nullptr;
  m_lineCount = 0;


}
  // Name - ~Document() - Destructor
  // Desc - Removes all lines from Document (removes all nodes from linked list)
  // Preconditions - None
  // Postconditions - Removes all lines and sets m_head to nullptr
  //                  and m_lineCount = 0
Document::~Document(){
  Line* curr = m_head;
  while (curr != nullptr) {
    Line* temp = curr;
    curr = curr->GetNext();
    delete temp;
  }
  m_head = nullptr;
  m_lineCount = 0;
}
  // Name - InsertLine(string,int)
  // Desc - Inserts a new line (node) into the Document (linked list)
  //        Dynamically allocates new line and inserts line in position
  //        indicated. Inserts the line **before** the position.
  //        For example, if position 1 then inserts a new first line to the Document
  // Preconditions - Document exists
  // Postconditions - New line inserted into the Document
void Document::InsertLine(string text, int position){
  if (position < 1 || position > m_lineCount + 1) {
    cout << "Invalid" << endl;
    return;
  }
  Line* newLine = new Line(text);
  if (position == 1) {
    newLine->SetNext(m_head);
    m_head = newLine;
  } else {
    Line* temp = m_head;
    for (int i = 1; i < position - 1; i++) {
      temp = temp->GetNext();
    }
    newLine->SetNext(temp->GetNext());
    temp->SetNext(newLine);
  }
  m_lineCount++;
}
  // Name - DeleteLine(int)
  // Desc - Deletes a line from the Document at a provided position
  //        Deletes the exact line chosen.
  //        Indicates the document is empty if the Document has no lines
  // Preconditions - Document exists and line exists
  // Postconditions - Line removed from Document

void Document::DeleteLine(int position) {
  if (position < 1 || position > m_lineCount) {
    cout << "Must be between 1 and " << m_lineCount << endl;
        return;
  }
  

  Line* toDelete = m_head;
  if (position == 1) { 
    m_head = m_head->GetNext();
  } else {
    Line* current = m_head;
    for (int i = 1; i < position - 1; i++) {
      current = current->GetNext();
    }
    toDelete = current->GetNext();
    current->SetNext(toDelete->GetNext());
  }
  delete toDelete;
  m_lineCount--;
}

      
  // Name - EditLine(int, string)
  // Desc - Edits the text in a specific Line at a provided position (line number).
  //        Updates the string in a specific Line. Uses the exact line number.
  //        Indicates the document is empty if the Document has no Lines
  // Preconditions - Document exists and line exists.
  // Postconditions - Line text updated at a provided position
void Document::EditLine(int position, string newText){
  if (position < 1 || position > m_lineCount) {
    cout << "Must be between 1 and " << m_lineCount << endl;
        return;
    }

  Line* current = m_head;
  for (int i = 1; i < position; i++) {
    current = current->GetNext();
  }
  current->SetText(newText);
}
    
  // Name - DisplayDocument
  // Desc - Iterates through the Document and displays all data in Line
  //        Indicates the document is empty if the Document has no lines
  // Preconditions - Document exists
  // Postconditions - Displays all lines in Document
void Document::DisplayDocument(){
  if (m_lineCount == 0) {
    cout << "The document is empty." << endl;
    return;
  }
  cout << "**Display Document**" << endl;
  Line* current = m_head;
  int lineNum = 1;
  while (current != nullptr) {
    cout << lineNum << ": " << current->GetText() << endl;
    current = current->GetNext();
    lineNum++;
  }
}


  // Name - SearchWord(string)
  // Desc - Iterates through the Document and searches for provided text
  //        Uses the "find" command in string
  //        Returns any complete word or any substring.
  //        For example, if you search for 'a' then it will
  //           return any line that has an 'a' in any word.
  //        Details: https://cplusplus.com/reference/string/string/find/
  //        Indicates if string not found
  // Preconditions - Document exists

  // Postconditions - Indicates line number where found or not
void Document::SearchWord(string word){
  if (m_lineCount == 0) {  
    cout << "The document is empty." << endl;
    return;
  }
  cout << "**Search Document**" << endl;
  

  Line* current = m_head;
  int lineNum = 1;
  bool found = false;
  while (current != nullptr) {
    if (current->GetText().find(word) != string::npos) {
      cout << "Word found in line " << lineNum << ": " << current->GetText() << endl;
      found = true;
    }
    current = current->GetNext();
    lineNum++;
  }
  
  if (!found) {  
    cout << "Word not found in the document." << endl;
  }
 }
//   // Name - SaveToFile(string)
//   // Desc - Iterates through the Document and saves all lines to
//   //        provided filename
//   // Preconditions - Document exists
//   // Postconditions - Writes all lines in Document to file
void Document::SaveToFile(string filename){
  ofstream outFile(filename);
  if (!outFile) {
    cout << "Error opening file for writing." << endl;
    return;
  }
  
  Line* current = m_head;
  while (current != nullptr) {
    outFile << current->GetText() << endl;
    current = current->GetNext();
  }
  
  outFile.close();
  cout << "File saved successfully!" << endl;
}
//   // Name - LoadFromFile(string)
//   // Desc - For each line in the input file, inserts one line
//   //        into the Document
//   // Preconditions - Document exists
//   // Postconditions - Writes all from file to Document
void Document::LoadFromFile(string filename){
  ifstream inFile(filename);
  if (!inFile) {
    cout << "Error opening file for reading." << endl;
    return;
  }
  
  string line;
  while (getline(inFile, line)) {
    InsertLine(line, m_lineCount + 1);
  }
  
  inFile.close();
  cout << "File loaded successfully!" << endl;
}
  // Name - GetLineCount();
  // Desc - Returns m_lineCount
  // Preconditions - Document exists
  // Postconditions - Returns m_lineCount
int Document::GetLineCount(){
  return m_lineCount;
}



