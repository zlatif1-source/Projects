/*****************************************
** File: Proj1.cpp
** Project: CMSC 202 Project 1, Spring 2025
** Author: Zain Latif
** Date: 2/18/2025
** Section: 10/14
** E-mail: zlatif1@umbc.edu
**
** This file contains the main driver program for Project 1.
** This program allows the user to play TIC TAC TOE.
** 
** 
** 
**
**
***********************************************/
#include <iostream>
#include <fstream>
using namespace std;
const int BOARD_SIZE = 3; // board size 3x3
const char PLAYER_X = 'X'; // The first player who plays
const char PLAYER_O = 'O'; // The second player who plays
void drawboard(char board[BOARD_SIZE][BOARD_SIZE]); // Function prototype
void playGame(); // shows playgame
// Pre-Condition: This is a function which allows the game to play and in order to accept input you need to put a space (EX: 1 1 (NOT: 11))
// Post-Condition: Should be able to iterate through the game and allow the user to finish the game or continue 
void mainMenu();
bool checkWin(char board[BOARD_SIZE][BOARD_SIZE], char player);
void saveBoard(char board[BOARD_SIZE][BOARD_SIZE]);


int main() {
    mainMenu();
    

    
        return 0;
    }
    void drawboard(char board[BOARD_SIZE][BOARD_SIZE]){ //function definition 
        cout << "-------" << endl;
        for (int i = 0; i < BOARD_SIZE; i++){
            for (int j = 0; j < BOARD_SIZE; j++){ // draws board
                cout << "|" << board[i][j];
                
                
                
            }
            cout << "|" << endl;
            cout << "-------" << endl;
        }
    }
    void playGame() { // allows the game to run
        char board[BOARD_SIZE][BOARD_SIZE] = {' ',' ',' ',' ',' ',' ',' ',' ',' '};
        int row = 0;
        int col = 0;
        int turn = 1;
	int size = 9;
        char playerX, playerO, currentPlayer;
        cout << "Player 1, do you want to be X or O? (Enter X or O): ";
        cin >> playerX;
        while (playerX != 'X' && playerX != 'O') { //keep asking until valid input
        cout << "Invalid choice. Please enter X or O: ";
        cin >> playerX;
            
        }
        if (playerX == 'X') {
            playerO = 'O';
            }else{
                playerO = 'X';
                
            }
        
            
        
        for (int move = 0; move < size; move++){ // keeps going until full
            drawboard(board); //Function call
            cout << endl;
            if (turn == 1) {
            currentPlayer = playerX; // Player 1's symbol
        } else {
            currentPlayer = playerO; // Player 2's symbol
        }
        
            do {
                cout << "Player " << currentPlayer << ", enter row (0-2) and column (0-2): ";
                cin >> row >> col;
                }while (row < 0 || row >= BOARD_SIZE || col < 0 || col >= BOARD_SIZE || board[row][col] != ' '); // checks valid input
                board[row][col] = currentPlayer;
                if (checkWin(board, currentPlayer)) {
                    drawboard(board);
                    cout << "Player " << currentPlayer << " Wins!" << endl;
                    return; //checks if three in a row
                }
                
                switch (turn) { //if entered O then player O is considered first
                    case 1:
                        turn = 2;
                        break;
                    case 2:
                        turn = 1;
                        break;
                }
		saveBoard(board);
                
                    
                
                
        
    }
    drawboard(board);
    cout << "Its a tie!" << endl;
    
    }
    
    void mainMenu() {
      int choice = 0;
        do {
            cout << "What would you like to do?" << endl;
            cout << "1. Play game" << endl;
            cout << "2. Quit" << endl;
            cout << "Enter your choice: ";
            cin >> choice; 

            if (choice == 1) {
                playGame();
            } else if (choice == 2) {
                cout << "Thanks for playing Tic-Tac-Toe." << endl;
            } else {
	      cout << "Invalid choice." << endl;
	    }
        } while (choice != 2); 
    }
    
            
        
            
        
        
    
    bool checkWin(char board[BOARD_SIZE][BOARD_SIZE], char currentPlayer){
        for (int i = 0; i < BOARD_SIZE; i++) { //checks for rows and columns
        if (board[i][0] == currentPlayer && board[i][1] == currentPlayer
            && board[i][2] == currentPlayer)
            return true;
        if (board[0][i] == currentPlayer && board[1][i] == currentPlayer
            && board[2][i] == currentPlayer)
            return true;
    }
    if (board[0][0] == currentPlayer && board[1][1] == currentPlayer
        && board[2][2] == currentPlayer){ //checks for diagonal 
            return true;
        }
    if (board[0][2] == currentPlayer && board[1][1] == currentPlayer  && board[2][0] == currentPlayer) {
            return true;
            
        }
        
    return false;
    }
    void saveBoard(char board[BOARD_SIZE][BOARD_SIZE]) {
    ofstream myfile("proj1_data.txt"); //Open file for writing
    if (myfile.is_open()) {
        for (int i = 0; i < BOARD_SIZE; i++) {
            for (int j = 0; j < BOARD_SIZE; j++) {
                myfile << board[i][j] << " ";
            }
            myfile << endl;
        }
        myfile.close(); //Close the file
    } else {
        cout << "Unable to open file" << endl;
    }
}





