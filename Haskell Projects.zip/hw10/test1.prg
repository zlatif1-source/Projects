_main()
  x y z
begin
  x := 3 * 5 ;
  y := 39 - x ;
  z := y / 3 ;
  print "x = " ;
  println x ;
  print "y = " ;
  println y ;
  print "z = " ;
  println z ;
end

