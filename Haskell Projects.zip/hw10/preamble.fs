( ---- begin preamble.fs ---- )

( Stack for Local Variables )
20000 CONSTANT _StackSize
VARIABLE _TheStack _StackSize CELLS ALLOT

( Initialize Stack & Environment pointers ) 

VARIABLE _SP
VARIABLE _EP
_TheStack _StackSize CELLS + dup _SP ! _EP !


( make aliases for access in PL )

' _SP alias stackFramePtr
' _EP alias environmentPtr


( helper functions )

\ copy array at src address to array at tgt
\ size of arrays at src[0] and tgt[0]

: copyArray ( src tgt -- )
    2dup @ swap @ min
    0 ?DO
	over cell+ I cells +
	over cell+ I cells +
	swap @ swap !

    LOOP
	drop drop
;

: rangeCheck ( addr index -- addr index )
    dup 1 < abort" array index less than 1"
    2dup swap @ > abort" array index exceeds size"
;


( ---- end preamble.fs ---- )
