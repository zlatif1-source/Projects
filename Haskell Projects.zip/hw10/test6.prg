_main () 
   power2
begin
   for power2 := 8 ; power2 <= 600 ; power2 := 2*power2 do
      print power2 ;
      print " " ;
   end
   println "" ;
end
