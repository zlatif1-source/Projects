_main()
begin
  println "Hello World" ;
  print   "Good-bye, " ;
  println "Blue skies" ;
end

