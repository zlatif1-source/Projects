

import PlayAGame
import SortaRandom

-- Zain Latif (zlatif1)

main = do
         putStrLn "Would you like to play a game?"
         putStrLn "Let's play I'm thinking of a number..."
         target <- getRandom 101
         n <- playAGame (target - 1) 0
         putStrLn $ "You found the number in " ++ (show n) ++ " guesses"
