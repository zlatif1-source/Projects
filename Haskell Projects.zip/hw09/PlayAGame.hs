module PlayAGame where

-- Zain Latif (zlatif1)

import Text.Read

playAGame :: Int -> Int -> IO Int
playAGame target tries = do
   putStrLn "Enter a number between 0 and 100 (inclusive):"
   str <- getLine
   case readMaybe str :: Maybe Int of

       Nothing -> do
                  putStrLn "That's not a number!"
                  playAGame target tries

       Just n  -> do
                  if n < 0 || n > 100 then do
                     putStrLn "You must pick a number between 0 and 100"
                     playAGame target tries

                  else if n < target then do
                     putStrLn "You should guess higher"
                     playAGame target (tries + 1)

                  else if n > target then do
                     putStrLn "You should guess lower"
                     playAGame target (tries + 1)

                  else do
                     putStrLn "You got it!"
                     return (tries + 1)
