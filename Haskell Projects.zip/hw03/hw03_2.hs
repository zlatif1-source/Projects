module HW03_2 where
-- Zain Latif (zlatif1)

rmax :: Ord a => [a] -> [a]
rmax [] = []
rmax xs = snd (helper xs)

-- helper returns max then with list with the max removed
helper :: Ord a => [a] -> (a, [a])
helper [x] = (x, [])

helper (x:xs) =
  let (m, rest) = helper xs
  in
    if x > m then
      (x, rest ++ [m])   -- the old max comes back
    else if x == m then
      (m, rest)
    else
      (m, x : rest)
