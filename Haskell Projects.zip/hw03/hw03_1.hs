module HW03_1 where
-- Zain Latif (zlatif1)

addcomma :: String -> String
addcomma []       = []
addcomma [x]      = [x]
addcomma (x:xs)   = x : ',' : addcomma xs
