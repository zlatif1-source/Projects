module TypeCheck where

import LangTypes
import ExpTree

type Report = [(String,TyETree)]
typeOK = ([] :: Report)


typeCheck :: TyETree -> Report

typeCheck root@(TT tp tr) 

    | tp == NADA = [("Type is NADA",root)]

    | EError  <-tr  = [("ETree is EError",root)]
    | CONST _ <- tr = typeOK

    | RVALUE nm (LocalArrayItemMode  _ tytr) <- tr = checkIndex nm tytr
    | RVALUE nm (GlobalArrayItemMode   tytr) <- tr = checkIndex nm tytr
    | RVALUE _ _ <- tr = typeOK

    | LVALUE _ _ <- tr = [("No L-values in experssion!",root)]

    | PLUS   lft rgt <- tr = checkArithmeticOp "PLUS"   lft rgt
    | TIMES  lft rgt <- tr = checkArithmeticOp "TIMES"  lft rgt
    | MINUS  lft rgt <- tr = checkArithmeticOp "MINUS"  lft rgt
    | DIVIDE lft rgt <- tr = checkArithmeticOp "DIVIDE" lft rgt

    | AND    lft rgt <- tr = checkLogicOp "AND" lft rgt
    | OR     lft rgt <- tr = checkLogicOp "OR"  lft rgt

    | NEG _ <- tr = typeOK  -- can't make my parser make this error

    | ETGt   lft rgt <- tr = checkIntComparison ">"  lft rgt
    | ETGtEq lft rgt <- tr = checkIntComparison ">=" lft rgt
    | ETLt   lft rgt <- tr = checkIntComparison "<"  lft rgt
    | ETLtEq lft rgt <- tr = checkIntComparison "<=" lft rgt

    | ETEq   lft rgt <- tr = checkAnyComparison "==" root lft rgt
    | ETNeq  lft rgt <- tr = checkAnyComparison "!=" root lft rgt

    | FUNC nm tytrs <- tr = checkParameters nm tytrs

-- -------------------------------------------------------------------

checkIndex :: String -> TyETree -> Report

checkIndex name tytr  

   | TT EInt _ <- tytr 
   = rprt

   | TT EBul _ <- tytr 
   = ("Index for array " ++ name ++ " cannot be EBul" , tytr) : rprt

   | TT NADA _ <- tytr 
   = ("Index for array " ++ name ++ " cannot be NADA" , tytr) : rprt

   where rprt = typeCheck tytr


-- -------------------------------------------------------------------

checkArithmeticOp :: String -> TyETree -> TyETree -> Report

checkArithmeticOp op left right
   | TT EInt _ <- left, TT EInt _ <- right
   = rprt

   | TT EInt _ <- left
   = ("Right subtree of " ++ op ++ " must be EInt", right) : rprt

   | TT EInt _ <- right
   = ("Left subtree of " ++ op ++ " must be EInt", left) : rprt

   | otherwise
   = [("Left subtree of " ++ op ++ " must be EInt", left),
      ("Right subtree of " ++ op ++ " must be EInt", right)] ++ rprt

   where rprt = typeCheck left ++ typeCheck right


-- -------------------------------------------------------------------

checkLogicOp :: String -> TyETree -> TyETree -> Report

checkLogicOp op left right
   | TT EBul _ <- left, TT EBul _ <- right
   = rprt

   | TT EBul _ <- left
   = ("Right subtree of " ++ op ++ " must be EBul", right) : rprt

   | TT EBul _ <- right
   = ("Left subtree of " ++ op ++ " must be EBul", left) : rprt

   | otherwise
   = [("Left subtree of " ++ op ++ " must be EBul", left),
      ("Right subtree of " ++ op ++ " must be EBul", right)] ++ rprt

   where rprt = typeCheck left ++ typeCheck right


-- -------------------------------------------------------------------

checkIntComparison :: String -> TyETree -> TyETree -> Report

checkIntComparison op left right
   | TT EInt _ <- left, TT EInt _ <- right
   = rprt

   | TT EInt _ <- left
   = ("Right subtree of " ++ op ++ " must be EInt", right) : rprt

   | TT EInt _ <- right
   = ("Left subtree of " ++ op ++ " must be EInt", left) : rprt

   | otherwise
   = [("Left subtree of " ++ op ++ " must be EInt", left),
      ("Right subtree of " ++ op ++ " must be EInt", right)] ++ rprt

   where rprt = typeCheck left ++ typeCheck right


-- -------------------------------------------------------------------

checkAnyComparison :: String -> TyETree -> TyETree -> TyETree -> Report

checkAnyComparison op root left right
   | TT ltp _ <- left, TT rtp _ <- right, ltp == rtp
   = rprt

   | otherwise
   = ("Subtrees of " ++ op ++ " must have same type", root) : rprt

   where rprt = typeCheck left ++ typeCheck right


-- -------------------------------------------------------------------

checkParameters :: String -> [TyETree] -> Report 

checkParameters name tytrs =
   [("In function call to " ++ name ++ ": " ++ msg, tr)
      | (msg, tr) <- concat [typeCheck tytr | tytr <- tytrs]]

