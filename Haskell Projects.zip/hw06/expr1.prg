3 + 4 * 5
a? || (x < 7)
&A[7] - B[i]
@function (1, 2, 3, 4)
x == 3
flag? != false
