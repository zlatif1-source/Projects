module ExpParser where
-- Zain Latif (zlatif1)

import LangTypes
import Token
import ExpTree

{-

A recursive descent parser for the grammar:

  E -> T Ttl

  Ttl -> + T Ttl 
       | - T Ttl 
       | "&&" T Ttl 
       | "||" T Ttl
       | epsilon

  T -> F Ftl

  Ftl -> * F Ftl 
       | / F Ftl 
       | <    F CompTl
       | "<=" F CompTl
       | >    F CompTl
       | ">=" F CompTl
       | "==" F CompTl
       | "!=" F CompTl
       | epsilon

  F -> id 
     | val 
     | ~ F 
     | ( E ) 
     | arr [ E ]
     | fn ( args )

-}


-- ---------------------------------------------------------------------------
-- constant to represent empty TyETree

ttNull :: TyETree
ttNull = TT NADA (CONST 0)


-- ---------------------------------------------------------------------------

-- wrapper function that calls parseE 
-- and checks if E can generate the entire string

parse :: [Token] -> (Bool, TyETree)

parse tks 

   | (True, tks1, tytr) <- parseE tks
   = ([TkEOF] == tks1, tytr)

   | otherwise
   = (False, ttError)


-- ---------------------------------------------------------------------------

--  E -> T Ttl

parseE :: [Token] -> (Bool, [Token], TyETree)

parseE [] 
   = (False, [TkEOF], ttError)

parseE tks
   | (True, tks1, tytr1) <- parseT tks 
   , (True, tks2, tytr2) <- parseTtl tks1 tytr1
   = (True, tks2, tytr2)

   | otherwise
   = (False, tks, ttError)


-- ---------------------------------------------------------------------------

makeExpr :: Token -> TyETree -> TyETree -> (Bool, TyETree)

makeExpr tkop left right 
   | TkOp "+"  <- tkop = (True, TT EInt (PLUS  left right))
   | TkOp "-"  <- tkop = (True, TT EInt (MINUS left right))
   | TkOp "||" <- tkop = (True, TT EBul (OR    left right))
   | TkOp "&&" <- tkop = (True, TT EBul (AND   left right))
   | otherwise         = (False, ttNull)
   

-- ---------------------------------------------------------------------------

--  Ttl -> + T Ttl | - T Ttl | "||" T Ttl | "&&" T Ttl | epsilon
--  FIXED: left associative

parseTtl :: [Token] -> TyETree -> (Bool, [Token], TyETree)

parseTtl [] left
   = (True, [], left)

parseTtl (tkop:tks) left
   | (True, tks1, right) <- parseT tks
   , (True, newLeft) <- makeExpr tkop left right
   = parseTtl tks1 newLeft

   | otherwise
   = (True, tkop:tks, left)


-- ---------------------------------------------------------------------------

--  T -> F Ftl

parseT :: [Token] -> (Bool, [Token], TyETree)

parseT tks
   | (True, tks1, tytr1) <- parseF tks
   = parseFtl tks1 tytr1

   | otherwise
   = (False, tks, ttError)


-- ---------------------------------------------------------------------------

makeTerm :: Token -> TyETree -> TyETree -> (Bool, TyETree)

makeTerm tkop left right 
   | TkOp "*" <- tkop = (True, TT EInt (TIMES  left right))
   | TkOp "/" <- tkop = (True, TT EInt (DIVIDE left right))
   | otherwise        = (False, ttNull)


-- ---------------------------------------------------------------------------

makeComp :: Token -> TyETree -> TyETree -> (Bool, TyETree)

makeComp tkcmp left right 
   | TkComp "<"  <- tkcmp = (True, TT EBul (ETLt   left right))
   | TkComp "<=" <- tkcmp = (True, TT EBul (ETLtEq left right))
   | TkComp "==" <- tkcmp = (True, TT EBul (ETEq   left right))
   | TkComp "!=" <- tkcmp = (True, TT EBul (ETNeq  left right))
   | TkComp ">=" <- tkcmp = (True, TT EBul (ETGtEq left right))
   | TkComp ">"  <- tkcmp = (True, TT EBul (ETGt   left right))
   | otherwise           = (False, ttNull)


-- ---------------------------------------------------------------------------

--  Ftl -> * F Ftl | / F Ftl | comp F CompTl | epsilon
--  FIXED: left associative for * and /

parseFtl :: [Token] -> TyETree -> (Bool, [Token], TyETree)

parseFtl [] left
   = (True, [], left)

parseFtl (tkop@(TkOp _):tks) left
   | (True, tks1, right) <- parseF tks
   , (True, newLeft) <- makeTerm tkop left right
   = parseFtl tks1 newLeft

   | otherwise
   = (True, tkop:tks, left)

parseFtl (tkcmp@(TkComp _):tks) left
   | (True, tks1, right) <- parseF tks
   , (True, firstCmp) <- makeComp tkcmp left right
   = parseCompTl tks1 right firstCmp

   | otherwise
   = (True, tkcmp:tks, left)

parseFtl tks left
   = (True, tks, left)


-- ---------------------------------------------------------------------------
--  CompTl -> comp F CompTl | epsilon
--
-- prevRight = right side of previous comparison
-- builtBool = boolean tree built so far
--
-- Example:
--   1 <= x < 10
--   becomes:
--   (1 <= x) && (x < 10)

parseCompTl :: [Token] -> TyETree -> TyETree -> (Bool, [Token], TyETree)

parseCompTl [] _ builtBool
   = (True, [], builtBool)

parseCompTl (tkcmp@(TkComp _):tks) prevRight builtBool
   | (True, tks1, nextRight) <- parseF tks
   , (True, nextCmp) <- makeComp tkcmp prevRight nextRight
   , let newBool = TT EBul (AND builtBool nextCmp)
   = parseCompTl tks1 nextRight newBool


parseCompTl tks _ builtBool
   = (True, tks, builtBool)


-- ---------------------------------------------------------------------------

--  F -> id | val | ~ F | ( E ) | fid ( args ) | arr [ E ]

parseF :: [Token] -> (Bool, [Token], TyETree)

parseF [] 
   = (False, [], ttError)

parseF (tk:tks)

   -- local variable
   | TkId LocalVarId tp nm <- tk 
   = (True, tks, TT tp (RVALUE nm (LocalVarMode 0)))

   -- global variable
   | TkId GlobalVarId tp nm <- tk 
   = (True, tks, TT tp (RVALUE nm GlobalVarMode))

   -- local array item: A[expr]
   | TkId LocalArrayId tp nm <- tk
   , (TkPunc "[" : tks1) <- tks
   , (True, tks2, idxTree) <- parseE tks1
   , (TkPunc "]" : tks3) <- tks2
   = (True, tks3, TT tp (RVALUE nm (LocalArrayItemMode 0 idxTree)))

   -- bare local array name
   | TkId LocalArrayId tp nm <- tk
   = (True, tks, TT tp (RVALUE nm (LocalArrayMode 0)))

   -- global array item: &B[expr]
   | TkId GlobalArrayId tp nm <- tk
   , (TkPunc "[" : tks1) <- tks
   , (True, tks2, idxTree) <- parseE tks1
   , (TkPunc "]" : tks3) <- tks2
   = (True, tks3, TT tp (RVALUE nm (GlobalArrayItemMode idxTree)))

   -- bare global array name
   | TkId GlobalArrayId tp nm <- tk
   = (True, tks, TT tp (RVALUE nm GlobalArrayMode))

   -- function call: @foo(...)
   | TkId FPId tp nm <- tk
   , (TkPunc "(" : tks1) <- tks
   , (True, tks2, args) <- parseArgList tks1
   , (TkPunc ")" : tks3) <- tks2
   = (True, tks3, TT tp (FUNC nm args))

   | TkInt num <- tk 
   = (True, tks, TT EInt (CONST num))

   | TkBul True <- tk 
   = (True, tks, TT EBul (CONST (0-1)))

   | TkBul False <- tk
   = (True, tks, TT EBul (CONST 0))

   | TkOp "~" <- tk
   , (True, tks1, tytr1@(TT tp1 _)) <- parseF tks
   = (True, tks1, TT tp1 (NEG tytr1))
   
   | TkPunc "(" <- tk
   , (True, tks1, tytr1) <- parseE tks
   , (TkPunc ")" : tks2) <- tks1
   = (True, tks2, tytr1)

   | otherwise
   = (False, tk:tks, ttError)


-- ---------------------------------------------------------------------------
-- ArgList -> epsilon | E MoreArgs
-- MoreArgs -> , E MoreArgs | epsilon

parseArgList :: [Token] -> (Bool, [Token], [TyETree])

-- empty argument list: immediately see ')'
parseArgList (TkPunc ")" : tks)
   = (True, TkPunc ")" : tks, [])

parseArgList tks
   | (True, tks1, arg1) <- parseE tks
   , (True, tks2, restArgs) <- parseMoreArgs tks1
   = (True, tks2, arg1 : restArgs)

   | otherwise
   = (False, tks, [])


-- ---------------------------------------------------------------------------

parseMoreArgs :: [Token] -> (Bool, [Token], [TyETree])

parseMoreArgs (TkPunc "," : tks)
   | (True, tks1, arg1) <- parseE tks
   , (True, tks2, restArgs) <- parseMoreArgs tks1
   = (True, tks2, arg1 : restArgs)

   | otherwise
   = (False, TkPunc "," : tks, [])

parseMoreArgs tks
   = (True, tks, [])


-- ---------------------------------------------------------------------------