## basic factors ##   3
## basic factors ##   3A_16
## basic factors ##   true 
## basic factors ##   false
## basic factors ##   x 
## basic factors ##   &y 
## basic factors ##   flag? 
## factors ##   ~3
## factors ##   ( 3 + 4 )
## factors ##   ( 3 + x )
## factors ##   Array[17]
## factors ##   Flags?[17]
## factors ##   &GlobalArray[17]
## factors ##   &GlobalFlags?[17]
## factors ##   @callme(maybe?)
## factors ##   @callme(maybe?,867,5309)
## factors ##   @callme()
## factors ##   @callme?(maybe)
## factors ##   @callme?(maybe,867,5309)
## factors ##   @callme?()
## terms ##   3 * 4 * 5 * 6
## terms ##   3 * x * &y * 6
## terms ##   64 / 8 / 4 / 2
## terms ##   64 / x / 4 / 2
## terms ##   &B[17] * C[i]
## expressions ##   3 + 4 + 5
## expressions ##   3 + x + &y
## expressions ##   18 - 6 - 2 - 1
## expressions ##   18 - A[4] - 2 - C[z]
## combinations ##   3 * 4 * 5 * 6 + 7 * 8 * 9 * 10 * 11  - 256 / 16 / 4 / 2
## combinations ##   3 * 4 * 5 * (6 + 7) * 8 + 9 + 10 + 11  - 256 / 16 / 4 / 2
## combinations ##   @foo(3,4) * ( 7 + @bar() + 9 ) - ( A[@index(k)] / 2)
## basic comparisons ##    3 <  5
## basic comparisons ##    3 <= 5
## basic comparisons ##    3 == 5
## basic comparisons ##    3 != 5
## basic comparisons ##    3 >= 5
## basic comparisons ##    3 >  5
## basic comparisons ##    true == false
## basic comparisons ##    true != false
## basic comparisons ##    x? == false
## extended comparisons ##   3 < x < 15
## extended comparisons ##   3 < x < 15 <= y < 29
## extended comparisons ##   3 < x < 15 > y != 14
## extended comparisons ##   yes != no == false
## extended comparisons ##   why == yes != no != true 
## logical operations ##   ( x > 3 ) && ( y < 4 )
## logical operations ##   ( x > 3 ) || ( y < 4 )
## logical operations ##   ( ( 5 > w >= 3 ) && ( 2 < x < 7 )) || (( 39 > y >= 12 ) && ( flag == stop != true ))
