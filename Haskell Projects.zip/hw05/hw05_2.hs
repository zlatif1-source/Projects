module Lexer where
-- Zain Latif (zlatif1)

import Text.Regex.PCRE
import Data.Char
import LangTypes
import Token

-- type synonym to get ~= to give us an array of matches captured by ( )

type MatchType1 = Bool 
type MatchType2 = String
type MatchType3 = (String,String,String)
type MatchType4 = (String,String,String,[String])


-- str usually has linefeeds and carriage returns (!!)
-- We have to use \A and \Z instead of ^ and $ in the regex patterns
-- Also, the \ in regex patterns must be escaped in Haskell strings



lexer :: String -> [ Token ]

lexer str 

   -- base case that shouldn't happen
   |  "" <- str
   =  [TkError]


   -- base case reached $$
   |  (_,_,after,[_]) <- ( str =~ "\\A(\\$\\$)" :: MatchType4 )
   =  [TkEOF]


   -- remove leading whitespace. \s is white space in PCRE

   |  (_,_,after,[_]) <- ( str =~ "\\A(\\s+)" :: MatchType4 )

   =  lexer after

   -- looking for multi-line comments
   
   | (_,_,after,_) <- ( str =~ "\\A##([\\s\\S]*?)##" :: MatchType4 )

   = lexer after

   -- looking for single-line commands

   | (_,_,after,_) <- ( str =~ "\\A#.*(\\n|\\Z)" :: MatchType4 )

   = lexer after


   -- Look for two-character comparisons

   |  (_,_,after,[match]) <- ( str =~ "\\A(<=|==|!=|>=)" :: MatchType4 )

   =  TkComp match : lexer after


   -- Look for two-character operators

   |  (_,_,after,[match]) <- ( str =~ "\\A(:=|&&|\\|\\|)" :: MatchType4 )

   =  TkOp match : lexer after


   -- Look for single-character comparisons

   |  (_,_,after,[match]) <- ( str =~ "\\A([<>])" :: MatchType4 )

   =  TkComp match : lexer after


   -- Look for single-character arithmetic operators

   |  (_,_,after,[match]) <- ( str =~ "\\A([\\*\\/\\+\\-~])" :: MatchType4 )

   =  TkOp match : lexer after


   -- Look for punctuation and delimiters

   |  (_,_,after,[match]) <- ( str =~ "\\A([()\\[\\],;:])" :: MatchType4 )

   =  TkPunc match : lexer after


   -- Look for string literals

   |  (_,_,after,[match]) <- ( str =~ "\\A\"([^\"]*)\"" :: MatchType4 ) 

   =  TkStr match : lexer after


   -- Look for integer numbers (with optional base)

   |  (_,_,after,[match]) <- ( str =~ "\\A([0-9][0-9a-zA-Z]*(_[0-9]+)?)" :: MatchType4 )

   =  case convertNum match of
         Just n  -> TkInt n : lexer after
         Nothing -> TkError : lexer after


   -- Look for identifiers and keywords

   |  (_,_,after,[match]) <- ( str =~ "\\A([&@_]?[a-zA-Z][a-zA-Z0-9]*\\??)" :: MatchType4 )

   =  classify match : lexer after


   -- Deal with errors
   |  otherwise

   =  TkError : lexer (tail str)


convertNum :: String -> Maybe Int
convertNum str =
  let (digits,base) =
        case span (/= '_') str of
          (d,"")    -> (d,10)
          (d,_:b)   -> (d, read b :: Int)
  in if base < 2 || base > 36
        then Nothing
        else convertBase digits base


convertBase :: String -> Int -> Maybe Int
convertBase ds base = foldl step (Just 0) ds
  where
    step Nothing _ = Nothing
    step (Just acc) c =
      let v = charVal c
      in if v < 0 || v >= base
            then Nothing
            else Just (acc * base + v)


charVal :: Char -> Int
charVal c
  | isDigit c = ord c - ord '0'
  | isAlpha c = ord (toLower c) - ord 'a' + 10
  | otherwise = -1



keywords =
 ["begin","do","else","elsif","end","extern","for",
  "global","if","loop","print","println",
  "return","then","until","while"]


classify str
  | base == "true"  = TkBul True
  | base == "false" = TkBul False
  | base `elem` keywords =
        if hasAdornment str then TkError
        else TkKW base
  | otherwise =
        case determine str of
          Just tok -> tok
          Nothing  -> TkError
  where
    base = strip str


strip s =
  let s1 = if head s `elem` "&@_" then tail s else s
  in if last s1 == '?' then init s1 else s1


hasAdornment s =
  head s `elem` "&@_" || last s == '?'


determine s =
  let hasQ = last s == '?'
      noQ  = if hasQ then init s else s
      (pref,name) =
        if head noQ `elem` "&@_"
           then (head noQ, tail noQ)
           else (' ',noQ)
      etype = if hasQ then EBul else EInt
  in if null name then Nothing
     else case pref of
        '&' -> Just (TkId
                    (if isUpper (head name)
                        then GlobalArrayId
                        else GlobalVarId)
                    etype name)
        '@' -> if isUpper (head name)
                  then Nothing
                  else Just (TkId FPId etype name)
        '_' -> Just (TkId FPId etype name)
        _   -> Just (TkId
                    (if isUpper (head name)
                        then LocalArrayId
                        else LocalVarId)
                    etype name)