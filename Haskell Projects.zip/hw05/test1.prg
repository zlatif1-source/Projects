: 3x >R 3 R@ * Rdrop ; 
