begin do else elsif end extern 
false for global if loop print println 
return then true until while

flag123x? &gflag123x?
num &globNum
Array GArray

@isOdd? 
@getNum
_doThis2

forest? 
returned
printer 
&falsehood? 
_forgo
&beginning 
Begin
@dock?
@iffy
_ending 
Else

begin? &else? 
&elsif @end
@false? @global
_if
