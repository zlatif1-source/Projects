# this is a comment
# nothing after the line matters not even # still a comment ## even now
x := 3 + 4 ;  # comments can begin anywhere
y := 7 * 9 ;

## multi-line comment
keep going
and going
until ##

## stop at first ## z := 4 - 2 ; ## ignore ##
## another test ### now single line comment ## q := 1 + 2 ;
