module HW04_5 where
-- Zain Latif (zlatif1)

-- calculate the "worth" of a string
worth :: String -> Int
worth str
  | take 2 str == "ab" && length str >= 5 && length str <= 9 = 13
  | take 2 str == "xy" = 5 + worth (drop 2 str)
  | take 2 str == "xz" = 5 + worth (drop 2 str)
  | str == "q" = 9
  | otherwise = 0