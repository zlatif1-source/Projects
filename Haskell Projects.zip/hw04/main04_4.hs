-- CMSC 331 Section 03&5 Homework 4 Question 4 Test File

import HW04_4

main = do
   print $ ptriples 13
   putStr "\n"
   print $ ptriples 25
