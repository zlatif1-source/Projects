module HW04_4 where
-- Zain Latif (zlatif1)

-- generate all Pythagorean triples (a,b,c) with a,b,c <= n
ptriples :: Int -> [(Int, Int, Int)]
ptriples n = [ (a,b,c) 
             | a <- [1..n]
             , b <- [1..n]
             , c <- [1..n]
             , a^2 + b^2 == c^2
             ]