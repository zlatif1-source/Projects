## constant folding combo ##    (3 + 4) * (9 - 7) - 10  
## constant folding & algebraic identities ##    ( (3 + 4) * (9 - 7) - 13 ) * ( x - 0)
## toss in comparisons ##   (((3 + 4) * (9 - 7) - 14 ) * x) <  ((2 + 4 + 5)/10)
## comparo-rama ##   (3 < 5) == (7 > 9)
## comparo-rama ##   (3 < 2) == (7 > 9) == (8 >= 8) 
## comparo-rama ##   (3 < 2) == (7 > 9) == (8 >= 8) != (true || x? || y?  || z?)
