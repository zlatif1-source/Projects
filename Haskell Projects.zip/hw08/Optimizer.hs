module Optimizer where
-- Zain Latif (zlatif1) 
import LangTypes
import ExpTree

-- --------------------------------------------------------
-- Wrapper optimize function
-- Optimizing an expression tree does not change its type

optimize :: TyETree -> TyETree
optimize ( TT typ etree ) = TT typ (opt etree)

-- --------------------------------------------------------
-- Recursive opt function

opt :: ETree -> ETree


-- --------------------------------------------------------
-- Optimizations for PLUS
-- --------------------------------------------------------

opt ( PLUS (TT EInt lft) (TT EInt rgt) )

   | lft' == CONST 0 = rgt'
   | rgt' == CONST 0 = lft'
   | CONST x <- lft', CONST y <- rgt' = CONST (x + y)
   | otherwise = PLUS (TT EInt lft') (TT EInt rgt')

   where lft' = opt lft ; rgt' = opt rgt


-- --------------------------------------------------------
-- Optimizations for MINUS
-- --------------------------------------------------------

opt ( MINUS (TT EInt lft) (TT EInt rgt) )

   | rgt' == CONST 0 = lft'
   | lft' == rgt'    = CONST 0
   | lft' == CONST 0 = NEG (TT EInt rgt')
   | CONST x <- lft', CONST y <- rgt' = CONST (x - y)
   | otherwise = MINUS (TT EInt lft') (TT EInt rgt')

   where lft' = opt lft ; rgt' = opt rgt


-- --------------------------------------------------------
-- Optimizations for TIMES
-- --------------------------------------------------------

opt ( TIMES (TT EInt lft) (TT EInt rgt) )

   | lft' == CONST 1    = rgt'
   | rgt' == CONST 1    = lft'
   | lft' == CONST 0    = CONST 0
   | rgt' == CONST 0    = CONST 0
   | CONST x <- lft', CONST y <- rgt' = CONST (x * y)
   | lft' == CONST (-1) = NEG (TT EInt rgt')
   | rgt' == CONST (-1) = NEG (TT EInt lft')
   | otherwise = TIMES (TT EInt lft') (TT EInt rgt')

   where lft' = opt lft ; rgt' = opt rgt


-- --------------------------------------------------------
-- Optimizations for DIVIDE
-- --------------------------------------------------------

opt ( DIVIDE (TT EInt lft) (TT EInt rgt) )

   | rgt' == CONST 1    = lft'
   | rgt' == CONST (-1) = NEG (TT EInt lft')
   | CONST x <- lft', CONST y <- rgt' = CONST (div x y)
   | otherwise = DIVIDE (TT EInt lft') (TT EInt rgt')

   where lft' = opt lft ; rgt' = opt rgt


-- --------------------------------------------------------
-- Optimizations for NEG
-- --------------------------------------------------------

opt ( NEG (TT typ exp1) )

   | NEG (TT _ inner) <- exp1' = inner
   | CONST x <- exp1', typ == EInt = CONST (-x)
   | CONST x <- exp1', typ == EBul =
       case x of
          0  -> CONST (-1)
          (-1) -> CONST 0
          _  -> NEG (TT typ exp1')
   | otherwise = NEG (TT typ exp1')

   where exp1' = opt exp1


-- --------------------------------------------------------
-- Optimizations for AND
-- --------------------------------------------------------

opt ( AND (TT EBul lft) (TT EBul rgt) )

   | lft' == CONST (-1) = rgt'
   | rgt' == CONST (-1) = lft'
   | lft' == CONST 0    = CONST 0
   | rgt' == CONST 0    = CONST 0
   | CONST x <- lft', CONST y <- rgt' =
       if x /= 0 && y /= 0 then CONST (-1) else CONST 0
   | otherwise = AND (TT EBul lft') (TT EBul rgt')

   where lft' = opt lft ; rgt' = opt rgt


-- --------------------------------------------------------
-- Optimizations for OR
-- --------------------------------------------------------

opt ( OR (TT EBul lft) (TT EBul rgt) )

   | lft' == CONST (-1) = CONST (-1)
   | rgt' == CONST (-1) = CONST (-1)
   | lft' == CONST 0    = rgt'
   | rgt' == CONST 0    = lft'
   | CONST x <- lft', CONST y <- rgt' =
       if x /= 0 || y /= 0 then CONST (-1) else CONST 0
   | otherwise = OR (TT EBul lft') (TT EBul rgt')

   where lft' = opt lft ; rgt' = opt rgt


-- --------------------------------------------------------
-- Optimizations for ETEq
-- --------------------------------------------------------

opt ( ETEq (TT typ lft) (TT _ rgt) )

   | typ == EBul && rgt' == CONST (-1) = lft'
   | typ == EBul && lft' == CONST (-1) = rgt'
   | typ == EBul && rgt' == CONST 0    = NEG (TT EBul lft')
   | typ == EBul && lft' == CONST 0    = NEG (TT EBul rgt')
   | CONST x <- lft', CONST y <- rgt' =
       if x == y then CONST (-1) else CONST 0
   | otherwise = ETEq (TT typ lft') (TT typ rgt')

   where lft' = opt lft ; rgt' = opt rgt


-- --------------------------------------------------------
-- Optimizations for ETNeq
-- --------------------------------------------------------

opt ( ETNeq (TT typ lft) (TT _ rgt) )

   | typ == EBul && rgt' == CONST (-1) = NEG (TT EBul lft')
   | typ == EBul && lft' == CONST (-1) = NEG (TT EBul rgt')
   | typ == EBul && rgt' == CONST 0    = lft'
   | typ == EBul && lft' == CONST 0    = rgt'
   | CONST x <- lft', CONST y <- rgt' =
       if x /= y then CONST (-1) else CONST 0
   | otherwise = ETNeq (TT typ lft') (TT typ rgt')

   where lft' = opt lft ; rgt' = opt rgt


-- --------------------------------------------------------
-- Optimizations for ETLt
-- --------------------------------------------------------

opt ( ETLt (TT EInt lft) (TT EInt rgt) )

   | CONST x <- lft', CONST y <- rgt' =
       if x < y then CONST (-1) else CONST 0
   | otherwise = ETLt (TT EInt lft') (TT EInt rgt')

   where lft' = opt lft ; rgt' = opt rgt


-- --------------------------------------------------------
-- Optimizations for ETLtEq
-- --------------------------------------------------------

opt ( ETLtEq (TT EInt lft) (TT EInt rgt) )

   | CONST x <- lft', CONST y <- rgt' =
       if x <= y then CONST (-1) else CONST 0
   | otherwise = ETLtEq (TT EInt lft') (TT EInt rgt')

   where lft' = opt lft ; rgt' = opt rgt


-- --------------------------------------------------------
-- Optimizations for ETGt
-- --------------------------------------------------------

opt ( ETGt (TT EInt lft) (TT EInt rgt) )

   | CONST x <- lft', CONST y <- rgt' =
       if x > y then CONST (-1) else CONST 0
   | otherwise = ETGt (TT EInt lft') (TT EInt rgt')

   where lft' = opt lft ; rgt' = opt rgt


-- --------------------------------------------------------
-- Optimizations for ETGtEq
-- --------------------------------------------------------

opt ( ETGtEq (TT EInt lft) (TT EInt rgt) )

   | CONST x <- lft', CONST y <- rgt' =
       if x >= y then CONST (-1) else CONST 0
   | otherwise = ETGtEq (TT EInt lft') (TT EInt rgt')

   where lft' = opt lft ; rgt' = opt rgt


-- --------------------------------------------------------
-- Optimize function calls
-- --------------------------------------------------------

opt ( FUNC fname params ) =
   FUNC fname (map optimize params)


-- --------------------------------------------------------
-- Optimize array indexes inside RVALUE / LVALUE
-- --------------------------------------------------------

opt ( RVALUE name (LocalArrayItemMode n idx) ) =
   RVALUE name (LocalArrayItemMode n (optimize idx))

opt ( RVALUE name (GlobalArrayItemMode idx) ) =
   RVALUE name (GlobalArrayItemMode (optimize idx))

opt ( LVALUE name (LocalArrayItemMode n idx) ) =
   LVALUE name (LocalArrayItemMode n (optimize idx))

opt ( LVALUE name (GlobalArrayItemMode idx) ) =
   LVALUE name (GlobalArrayItemMode (optimize idx))


-- --------------------------------------------------------
-- Catch simple leaves
-- --------------------------------------------------------

opt ( RVALUE name mode ) = RVALUE name mode
opt ( LVALUE name mode ) = LVALUE name mode
opt ( CONST x ) = CONST x
opt EError = EError


-- --------------------------------------------------------
-- Catch all case where no optimizations can be done

opt x = x