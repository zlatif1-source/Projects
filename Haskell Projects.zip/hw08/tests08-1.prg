## constant folding ##   13 + 4
## constant folding ##   13 - 4
## constant folding ##   13 * 4
## constant folding ##   13 / 4
## constant folding ##   3 - ~1 
## constant folding ##   A[ 3 + 4 ] 
## constant folding ##  &B?[ 9 - 7 ] 
## constant folding ##  @foo?(2*3,4*5,12/6)
## constant folding ##  @bar(10-8-4-1)
