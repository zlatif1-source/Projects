## algebraic identities ##   x + 0
## algebraic identities ##   0 + x
## algebraic identities ##   x - 0
## algebraic identities ##   0 - x
## algebraic identities ##   (a + b + c) - (a + b + c)
## algebraic identities ##   x * 1
## algebraic identities ##   1 * x
## algebraic identities ##   (0-1) * x
## algebraic identities ##   x * (0-1)
## algebraic identities ##   ~ ( x * (0-1) )
## algebraic identities ##   x * 0
## algebraic identities ##   0 * x
## algebraic identities ##   x / 1
## algebraic identities ##   x / (0-1)
## algebraic identities ##   x?    && true 
## algebraic identities ##   true  && x?
## algebraic identities ##   x?    && false
## algebraic identities ##   false && x?
## algebraic identities ##   x?    || true 
## algebraic identities ##   true  || x?
## algebraic identities ##   x?    || false
## algebraic identities ##   false || x?
## algebraic identities ##   x?    == true 
## algebraic identities ##   true  == x?
## algebraic identities ##   x?    == false
## algebraic identities ##   false == x?
## algebraic identities ##   x?    != true 
## algebraic identities ##   true  != x?
## algebraic identities ##   x?    != false
## algebraic identities ##   ~ ~ (x < 5) 
## algebraic identities ##   A? [ 1*x + 0*y ]
## algebraic identities ##   &B [ 1*x + 0*y ]
## algebraic identities ##   @foo ( 1*x, 0*y, z -0)
## algebraic identities ##   @foo?( 1*x, 0*y, z -0)
